﻿using System;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1) && int.TryParse(textBox2.Text, out int var2))
            {
                int resultado = var1 * var2;

                textBox3.Text = ("" + resultado);
            }
            else
            {
                textBox3.Text = "Erro. digite o campo requerido.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int var1) && int.TryParse(textBox2.Text, out int var2))
            {
                this.Text = "Roof Builder - Metragem e Calculo para Telhado Residencial";


                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // chama metodo limpar
            }
            else
            {
                textBox3.Text = "Erro. nada para apagar.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var1) && int.TryParse(textBox5.Text, out int var2))
            {
                int resultado = var1 + var2;

                textBox6.Text = ("" + resultado);
            }
            else
            {
                textBox6.Text = "Erro. digite o campo requerido.";
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var1) && int.TryParse(textBox5.Text, out int var2))
            {
                int resultado = var1 - var2;

                textBox6.Text = ("" + resultado);
            }
            else
            {
                textBox6.Text = "Erro. digite o campo requerido.";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var1) && int.TryParse(textBox5.Text, out int var2))
            {
                int resultado = var1 / var2;

                textBox6.Text = ("" + resultado);
            }
            else
            {
                textBox6.Text = "Erro. digite o campo requerido.";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var1) && int.TryParse(textBox5.Text, out int var2))
            {
                int resultado = var1 * var2;

                textBox6.Text = ("" + resultado);
            }
            else
            {
                textBox6.Text = "Erro. digite o campo requerido.";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int var1) && int.TryParse(textBox5.Text, out int var2))
            {
                this.Text = "Roof Builder - Metragem e Calculo para Telhado Residencial";


                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear(); // chama metodo limpar
            }
            else
            {
                textBox6.Text = "Erro. nada para apagar.";
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int var1) && int.TryParse(textBox9.Text, out int var2))
            {
                int resultado = var1 * var2;

                textBox8.Text = ("" + resultado);
            }
            else
            {
                textBox8.Text = "Erro. digite o campo requerido.";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int var1) && int.TryParse(textBox9.Text, out int var2))
            {
                this.Text = "Roof Builder - Metragem e Calculo para Telhado Residencial";


                textBox7.Clear();
                textBox9.Clear();
                textBox8.Clear(); // chama metodo limpar
            }
            else
            {
                textBox8.Text = "Erro. nada para apagar.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nPara calcular o metro quadrado do telhado com 4 lados iguais [metragem igual] fazemos o calculo Comprimento x Largura.\n" 
                + "\nPara calcular o metro quadrado com 4 lados diferentes [metragem diferente] somamos os dois lados paralelos, " 
                + "\nsomamos o comprimento com comprimento e dividimos por 2 tirando assim a media, "
                + "\nfazemos o mesmo com a largura, somamos a largura com largura e dividimos por 2 tirando a media, " 
                + "\ne com os resultados da media dos lados paralelos (largura e comprimento) "
                + "\nmultiplicamos os dois lados parelos Comprimento x Largura e assim obtemos os metros quadrados de um telhado com 4 lados diferentes.\n"
                + "\nPara calcular a Quantidade de Telhas por Metro Quadrado: \n" 
                + "\nTendo como base uma telha americana com dimensoes (43cx26l) em centimetros em vista de eixo horizontal, " 
                + "\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 12 telhas, " 
                + "\nassim um metro quadrado tem 12 telhas entao essa sera a medida padrao. 12 x tantos metros quadrados = a quantidade de telhas por metro quadrado.\n"
                + "\nPara calcular a Telha Colonial: 1 M² = 16 telhas.\n"
                + "\nPara calcular a Telha Italiana: 1 M² = 14 telhas.\n"
                + "\nPara calcular a Telha Portuguesa: 1 M² = 17 telhas.\n"
                + "\nPara calcular a Telha Romana: \n" 
                + "\nTendo como base uma telha romana com dimensoes (40cx21l) em centimetros em vista de eixo horizontal, " 
                + "\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 16 telhas,"
                + "\n assim um metro quadrado tem 16 telhas entao essa sera a medida padrao. 16 x tantos metros quadrados = a quantidade de telhas por metro quadrado.\n" 
                + "\nInformações Importantes: \n"
                + "\nObs: Este software foi desenvolvido com variaveis inteiras, então nao permite a inserção de numero e virgula (ex: 2,90 metros mude para 3 metros).\n"
                + "\nObs: O calculo do metro quadrado de telhado residencial neste software é feito sem o calculo da inclinação. " 
                + "\nSe o calculo do metro quadrado for feito com a inclinação, com o aumentar do grau de inclinação do telhado, " 
                + "\nira ocorrer um aumento na quantidade de telhas necessarias para telhar e construir um telhado residencial.\n"
                + "\nObs: a instalação, construção e dimensionamento de um telhado residencial requer um profissional qualificado e formado, como um engenheiro civil. \n"
                + "\nPadrão de telhas por Metro Quadrado e Quantidade de Telhas: \n"
                + "\n A quantidade de telhas pode variar para mais ou para menos, a depender das dimensões da telha escolhida, " 
                + "\nentão veja que no caso da instalação das telhas coloniais, sua arrumação (encaixe) das telhas vai ser feita com duas camadas de telhas, " 
                + "\no que pode acarretar na variação (para mais ou para menos) da quantidade de telhas necessarias para telhar um metro quadrado. " 
                + "\n Havendo assim uma possivel diferença no padrão e na quantidade de telhas do metro quadrado para a telha colonial como descrito acima.\n");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Text = "Sobre";
            MessageBox.Show("Sobre\n" + "\nSoftware: Roof Builder - Metragem e Calculo para Telhado Residencial \n" + "\nAuthor: PHNO" + "\nData Release: 14/10/2024" + "\nVersao Codigo: 0.0.0.1v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");

        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Text = "Roof Builder - Metragem e Calculo para Telhado Residencial";



            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // chama metodo limpar
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox10.Text, out int var10) && int.TryParse(textBox11.Text, out int var11) && int.TryParse(textBox12.Text, out int var12) && int.TryParse(textBox13.Text, out int var13))
            {
                int var14 = 2; // media
                int mult3 = var10 + var11;
                int div1 = mult3 / var14;
                int var15 = 2; // media
                int mult4 = var12 + var13;
                int div2 = mult4 / var15;

                int result = div2 * div1;

                textBox14.Text = ("" + result);
            }
            else
            {
                textBox14.Text = "Erro. digite o campo requerido.";
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox10.Text, out int var10) && int.TryParse(textBox11.Text, out int var11) && int.TryParse(textBox12.Text, out int var12) && int.TryParse(textBox13.Text, out int var13))
            {
                this.Text = "Roof Builder - Metragem e Calculo para Telhado Residencial";


                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
            }
            else
            {
                textBox14.Text = "Erro. nada para apagar.";
            }
            
        }
    }
}
